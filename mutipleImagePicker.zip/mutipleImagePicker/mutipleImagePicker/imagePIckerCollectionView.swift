//
//  imagePIckerCollectionView.swift
//  multipleImagePIckerFramework
//
//  Created by Boobesh Balasubramanian  on 24/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import Photos

class ImagePickerCollectionView:UIViewController,UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,PHPhotoLibraryChangeObserver{
    
    
    var delegate:MultipleImagePickerProtocol?
    /*outlets which handles dismissing the collection view */
    
    @IBOutlet weak var customCollectionView: UICollectionView!
    
    @IBAction func done(_ sender: Any) {
        
    }
    
    
    @IBOutlet weak var photosCollectionView: UICollectionView!
    
    var images:PHFetchResult<PHAsset>?
    let imageManager = PHCachingImageManager()
    var sourceType = PHFetchOptions()
    var collectionViewCellSize = CGSize()
    var imagesSelected = Set<PHAsset>()
    let collectionViewSelectedBackGroundImage = UIImageView()
    var collectionViewDeSelectionBackGroundImage = UIView()
    var photomanager = PHImageManager.default()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("view did load ")
        fetchMediaAssets()
        //setUpCollectionViewLayoutProperties()
        var view = UIView()
        view.backgroundColor = UIColor.clear
        
        // collectionviewbackgroundimages
        photosCollectionView.allowsMultipleSelection = true
        photosCollectionView.allowsSelection = true
        collectionViewSelectedBackGroundImage.image = UIImage(named:"tick")
        collectionViewSelectedBackGroundImage.contentMode = .scaleAspectFit
        collectionViewDeSelectionBackGroundImage = view
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        print("didReceiveMemoryWarning")
    }
    
    
    /* collection view delegate  methods*/
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (images?.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print("did select ")
        imagesSelected.insert((images?[indexPath.item])!)
        print("\(indexPath) and \(indexPath.row)")
       //collectionView.cellForItem(at: indexPath)?.layer.borderColor = UIColor.orange.cgColor
        var cell = collectionView.cellForItem(at: indexPath) as! CustomCollectionViewCell
       
        //collectionView.cellForItem(at: indexPath)?.contentView.backgroundColor = UIColor.orange
        if (cell.isSelected){
             cell.contentView.backgroundColor = UIColor.orange
        }else {
             cell.contentView.backgroundColor = UIColor.clear
        }

    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        print("did deselect ")
        imagesSelected.remove(at: (imagesSelected.index(of: (images?[indexPath.item])!))!)
       
        //collectionView.cellForItem(at: indexPath)?.layer.borderColor = UIColor.clear.cgColor
        
        delegate?.provideSelectedImages(selectedImages: imagesSelected)
        var selectedIndexPaths = customCollectionView.indexPathsForSelectedItems
        print("Selected index paths")
        print(selectedIndexPaths)
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        print("did highlight ")
        //collectionView.cellForItem(at: indexPath)?.layer.backgroundColor = UIColor.orange.cgColor
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        print("did unhighlight ")

        //collectionView.cellForItem(at: indexPath)?.layer.backgroundColor = UIColor.clear.cgColor
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "albumImage", for: indexPath) as! CustomCollectionViewCell
        cell.imageAssests = images?[indexPath.item]
       
        cell.layer.borderWidth = 2;
       
          print(indexPath)
        print(indexPath.row)
        return cell
    }
    
    /* collection view flow layout delegates  */
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width  = self.view.frame.width
        let height = self.view.frame.height
        return CGSize(width: width/4, height: height/6)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    /* photo library delegate methods which handle the changes  */
    
    func photoLibraryDidChange(_ changeInstance: PHChange){
        // yet to be implemented
        var change=changeInstance.changeDetails(for: images!)
        print(change?.changedIndexes)
    }
    
    /* methods which fetch the image Assests in the form of Phassests objects */
    
    func fetchMediaAssets() {
        sourceType.includeAssetSourceTypes = .typeUserLibrary
        images = PHAsset.fetchAssets(with: .image, options: nil)
        print("images assests count \(String(describing: images?.count))")
        PHPhotoLibrary.shared().register(self)
    }
    
    
    /* this method sets up the collection view layout properties */
    
    func setUpCollectionViewLayoutProperties(){
        collectionViewCellSize.width = 75
        collectionViewCellSize.height = 75
        let customizedFlowlayout = UICollectionViewFlowLayout()
        customizedFlowlayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0)
        customizedFlowlayout.minimumInteritemSpacing = 1
        customizedFlowlayout.minimumLineSpacing = 10
        customizedFlowlayout.itemSize = collectionViewCellSize
        photosCollectionView.collectionViewLayout = customizedFlowlayout
    }
    
    // provides the core UIImage Object after selecting multiple Images from the picker interface.
//    func provideSelectedImages(selectedImages:Set<PHAsset>)->[UIImage]{
//        var SelectedImagesArray = [UIImage]()
//        
//        SelectedImagesArray.removeAll()
//        for images in selectedImages{
//            self.photomanager.requestImage(for: images, targetSize:CGSize(width: 200, height: 200) , contentMode: .aspectFit, options: nil, resultHandler: {(resultImage,info ) in SelectedImagesArray.append(resultImage!)
//                print(resultImage?.size)
//                info?.description
//            })
//            
//        }
//        print(SelectedImagesArray.count)
//        return SelectedImagesArray
//    }
//    
    
    
}

// tips


//collection view -> indexpathsofselecteditems






