//
//  ViewController.swift
//  mutipleImagePicker
//
//  Created by IPhone Dev on 24/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import UIKit
import Photos

class ViewController: UIViewController,MultipleImagePickerProtocol {

    var imagepicker = ImagePickerCollectionView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        imagepicker.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func provideSelectedImages(selectedImages: Set<PHAsset>) {
        print("protocol")
    }
    
 
}

