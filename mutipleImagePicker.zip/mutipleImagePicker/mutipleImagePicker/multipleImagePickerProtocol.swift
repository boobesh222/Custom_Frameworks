//
//  multipleImagePickerProtocol.swift
//  mutipleImagePicker
//
//  Created by IPhone Dev on 05/06/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import UIKit
import Photos
protocol MultipleImagePickerProtocol {
    func provideSelectedImages(selectedImages:Set<PHAsset>)
}
