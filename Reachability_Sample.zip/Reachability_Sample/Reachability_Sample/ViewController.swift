//
//  ViewController.swift
//  Reachability_Sample
//
//  Created by Boobesh Balasubramanian on 07/02/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var signIn_Button: UIButton!
    @IBOutlet weak var networkStatusChange_TextField: UILabel!
    let networkStatus = Reachability()

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        do {
//            try networkStatus?.startNotifier()
//        } catch {
//            print("Unable to start notifier")
//        }
//        
        networkStatus?.whenReachable = { networkStatus in
            
            DispatchQueue.main.async {
                if networkStatus.isReachableViaWiFi {
                    print("Reachable via WiFi")
                    self.networkStatusChange_TextField.text = "Reachable via WiFi"
                    self.networkStatusChange_TextField.textColor = UIColor.green
                } else {
                    print("Reachable via Cellular")
                    self.networkStatusChange_TextField.text = "Reachable via Cellular"
                    self.networkStatusChange_TextField.textColor = UIColor.brown
                }
            }

        }
        
        
        
        networkStatus?.whenUnreachable = {networkStatus in
            DispatchQueue.main.async {
                self.networkStatusChange_TextField.text = "not reachable"
                self.networkStatusChange_TextField.textColor = UIColor.red
        }}
    
    
    }

    
    override func viewWillAppear(_ animated: Bool) {
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged),name: ReachabilityChangedNotification,object: networkStatus)
        do{
            try networkStatus?.startNotifier()
        }catch{
            print("could not start reachability notifier")
        }
    
    }
    
    func reachabilityChanged(note:Notification){
        let reachability = note.object as! Reachability
        
        if reachability.isReachable {
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        } else {
            print("Network not reachable")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

