import { DateSortingPipe } from './../../pipes/date-sorting/date-sorting';
import { FetchTasksProvider } from './../../providers/fetch-tasks/fetch-tasks';
import { NavController,Slides } from 'ionic-angular';
import { Component,ViewChild } from '@angular/core';




@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
 
 events:any = "Today"
 eventDataToday:any
 todayEventCount:string
 upcomingEventCount:string
 eventDataUpcoming:any
 @ViewChild('mySlider') slider: Slides;
  viewSlides: any;
  constructor(public navCtrl: NavController,public eventService:FetchTasksProvider) {

     this.eventService.getEventDetails().subscribe((events)=>{
          
            this.eventDataToday = events.today
            this.eventDataUpcoming = events.upcoming
            this.todayEventCount = "Today"+" - "+events.today.length
            this.upcomingEventCount = "Upcoming" + " - " + events.upcoming.length 
             
    })   

this.viewSlides = [
      {
        id: "today",
        title: "today"
      },
      {
        id: "upcoming",
        title: "upcoming"
      },
      
    ];


  }

sortBasedOnDate(){
  console.log(this.events)
       console.log(this.eventDataUpcoming)

    if (this.events == "Upcoming") {
      this.eventDataUpcoming.sort(function(name1,name2){
           
            if (name1.date.date < name2.date.date) {
                console.log(name1.date.date)
                 return -1;
            } else if(name1.date.date > name2.date.date) {
                 return 1
            }else{
              return 0
            }
      })
    } else {
        this.eventDataToday.sort(function(name1,name2){
          
           if (name1.date.date < name2.date.date) {
                 return -1;
            } else if(name1.date.date > name2.date.date) {
                 return 1
            }else{
              return 0
            }
      })
    }
    console.log(this.eventDataUpcoming)
}

sortBasedOnName(){
console.log("sorting of name started ")
    console.log(this.events)
    if (this.events == "Upcoming") {
      this.eventDataUpcoming.sort(function(name1,name2){
           
            if (name1.subject < name2.subject) {
                 return -1;
            } else if(name1.subject > name2.subject) {
                 return 1
            }else{
              return 0
            }
      })
    } else {
        this.eventDataToday.sort(function(name1,name2){
            console.log("inside sorting function ")
            console.log(name1.subject)
            console.log("name 2 " + name2.subject)
            if (name1.subject < name2.subject) {
                 return -1;
            } else if(name1.subject > name2.subject) {
                 return 1
            }else{
              return 0
            }
      })
    }


}




}
