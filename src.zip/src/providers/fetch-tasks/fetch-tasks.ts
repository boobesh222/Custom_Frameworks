import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable'; 
//import { Events } from './../../models/jsonModel';
import { Eventslist } from './../../models/jsonModel';
/*
  Generated class for the FetchTasksProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class FetchTasksProvider {
  baseUrl:string
  constructor(public http: Http) {
    // https://api.myjson.com/bins/1gknx3
  
    this.baseUrl = "https://api.myjson.com/bins/lgvf3"
  }

 getEventDetails():Observable<Eventslist>{
    return this.http.get(this.baseUrl)
      .map(res => <Eventslist>(res.json()))
  }


}
