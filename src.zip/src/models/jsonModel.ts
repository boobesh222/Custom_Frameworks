
export class Events{
        subject:string;
        location:string;
        date:{EventTimeDetails};

}

export class Eventslist{
  today:[Events];
  upcoming:[Events];

}


export class EventTimeDetails{
        day:string;
        month:string;
        month_name:string;
        time:string;
        full:string;
        date:String;
}