//
//  BarcodeScanner.swift
//  BarcodeScanner
//
//  Created by Boobesh Balasubramanian on 02/05/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

public class BarcodeScanner:NSObject,AVCaptureMetadataOutputObjectsDelegate{
    
    public var videoCaptureDevice: AVCaptureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    public var device = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    public var captureInput:AVCaptureDeviceInput?
    public var metadataOutput = AVCaptureMetadataOutput()
    public var previewLayer: AVCaptureVideoPreviewLayer?
    public var captureSession:AVCaptureSession?
    public var code: String?
    //var barcodehighlightingView:UIView?
    public var parentView:UIView?
    public var qrCodeFrameView:UIView?
    public var audioPlayer:AVAudioPlayer?
    //typealias cameraSetupCompletionHandler = ()->Void
    public var barcodeProtocol:barcodeResultProtocol?
    public var frameWorkBundle:Bundle?
    public var closeButtonImageView:UIImageView?
    
    
    
    
    public override init() {
        captureSession = AVCaptureSession()
        self.previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
    }
    
    /* Function which setup the camera for scanning the 1 and 2 dimentional barcodes and supports the 13 Symbolizes according to apple documentation   */
    
    public func setupCamera(previewViewForScanning:UIView,frameWidth:Double,frameHeight:Double,frameColour:CGColor){
        
        parentView = previewViewForScanning
        captureInput = try? AVCaptureDeviceInput(device: videoCaptureDevice)
        
        if (self.captureSession?.canAddInput(captureInput))! {
            self.captureSession?.addInput(captureInput)
        }
        
        if (previewLayer?.connection.isEnabled )!{
            print("preview layer enabled ")
        }else{
            print("layer not enabled ")
            previewLayer?.connection.isEnabled=true
        }
        
        /*  frame size customization logic --- still under construction partially  */
        let minFrameWidth :Double  = 150
        let minFrameHeight:Double  = 150
        let maxFramewidth :Double  = 400
        let maxFrameHeight:Double  = 400
        
        
        if ((frameWidth<maxFramewidth && frameWidth>minFrameWidth)&&(frameHeight<maxFrameHeight&&frameHeight>minFrameHeight)){
            print("if loop drawing rectangle focussing area")
            drawBarcodeFocusingArea(Width: frameWidth, height: frameHeight,colour: frameColour)
            //drawCloseButton()
        }else{
            let frameWidth = minFrameWidth
            let frameHeight = minFrameHeight
            print("else loop drawing rectangle focussing area")
            drawBarcodeFocusingArea(Width: frameWidth, height: frameHeight, colour: frameColour)
        }
        
        drawCloseButton()
        
        if let videoPreviewLayer = self.previewLayer {
            videoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
            videoPreviewLayer.frame = (parentView?.bounds)!
            parentView?.layer.addSublayer(videoPreviewLayer)
            
        }
        
        print("camera setted up")
        metadataOutput = AVCaptureMetadataOutput()
        if (self.captureSession?.canAddOutput(metadataOutput))! {
            self.captureSession?.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            print("metadata output delegate added ")
            metadataOutput.metadataObjectTypes = [AVMetadataObjectTypeUPCECode,
                                                  AVMetadataObjectTypeCode39Code,
                                                  AVMetadataObjectTypeCode39Mod43Code,
                                                  AVMetadataObjectTypeEAN8Code,
                                                  AVMetadataObjectTypeCode93Code,
                                                  AVMetadataObjectTypeCode128Code,
                                                  AVMetadataObjectTypePDF417Code,
                                                  AVMetadataObjectTypeAztecCode,
                                                  AVMetadataObjectTypeInterleaved2of5Code,
                                                  AVMetadataObjectTypeITF14Code,
                                                  AVMetadataObjectTypeDataMatrixCode,
                                                  AVMetadataObjectTypeQRCode,
                                                  AVMetadataObjectTypeEAN13Code]
            
        }else {
            print("Could not add metadata output")
        }
        
        
        
    }
    
    
    /* consecutive methods which starts and stops barcode scanning sessions  */
    
    public func startScanningSessionForBarcodes(){
        let captureSessionSerialQueue = DispatchQueue(label: "captureSessionQueue")
        captureSessionSerialQueue.sync {
            if (captureSession?.isRunning == false) {
                captureSession?.startRunning();
                print("session started")
            }
        }
        
    }
    
    public func stopScanningSessionForBarcodes(){
        if (captureSession?.isRunning == true) {
            captureSession?.stopRunning();
        }
    }
    
    /* delegate method which returns the captured output objects */
    
    public func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!){
        
        var resultBarcode:String?
        previewLayer?.connection.isEnabled = false
        self.captureSession?.removeOutput(metadataOutput)
        self.captureSession?.removeInput(captureInput)
        
        
        // stop the scanning when its only one time scanning use else dont stop it
        // stopScanningSessionForBarcodes()
        
        playSound()
        
        // remove the added subview and return the superviews
        self.previewLayer?.removeFromSuperlayer()
        self.qrCodeFrameView?.removeFromSuperview()
        self.closeButtonImageView?.removeFromSuperview()
        
        
        for metadata in metadataObjects {
            let readableObject = metadata as! AVMetadataMachineReadableCodeObject
            resultBarcode = readableObject.stringValue
            qrCodeFrameView?.frame = readableObject.bounds
            print(resultBarcode!)
            barcodeProtocol?.scannedBarcodeResult(resultBarcode!)
        }
        
    }
    
    
    /*  Gives sound feedback after detecting the barcode/qrcodes  */
    func playSound() {
        
        frameWorkBundle = Bundle.init(for:type(of: self))
        let soundFilePath = frameWorkBundle?.path(forResource:"beep",ofType:"mp3")
        print("sound path url\(String(describing: soundFilePath))")
        let fileURL = NSURL(string: soundFilePath!)! as URL
        print("trying to play the sound  @ \(String(describing: fileURL))")
        print("sound path url\(String(describing: soundFilePath))")
        //var error: NSError?
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: fileURL)
            audioPlayer!.play()
            audioPlayer!.volume = 1.0
        }catch {
            print ("error in playing sound ")
        }
    }
    
    
    /* this method  draws highlighting barcode for the focusing area   */
    /* creating  frameview  */
    /* the corresponding method requires width and height of the center focussing area and aswell the highlighting colour  and it has the default min and max width and height*/
    
    func drawBarcodeFocusingArea(Width:Double,height:Double,colour:CGColor){
        
        
        qrCodeFrameView = UIView()
        if let qrCodeFrameView = qrCodeFrameView {
            qrCodeFrameView.layer.borderColor = colour
            qrCodeFrameView.layer.borderWidth = 2
            qrCodeFrameView.frame = CGRect(x:0.0, y:0.0, width:Width, height:height)
            qrCodeFrameView.layer.zPosition = 1
            qrCodeFrameView.center = CGPoint(x:(parentView?.frame.size.width)!  / 2,
                                             y:(parentView?.frame.size.height)! / 2)
            parentView?.addSubview(qrCodeFrameView)
            parentView?.bringSubview(toFront: qrCodeFrameView)
        }
        
        
    }
    
    
    
    /*  draws the close button which is used to dismiss the scanning layer and its associated subviews*/
    func drawCloseButton(){
        
        frameWorkBundle = Bundle.init(for:type(of: self))
        let imagePath = frameWorkBundle?.path(forResource:"closeButton",ofType:"png")
        let image = UIImage(contentsOfFile: imagePath!)
        closeButtonImageView = UIImageView(image: image!)
        closeButtonImageView?.frame = CGRect(x: 10, y: 23, width: 30, height: 30)
        closeButtonImageView?.layer.zPosition = 1
        
        closeButtonImageView?.isUserInteractionEnabled = true
        closeButtonImageView?.addGestureRecognizer(gestureProvider())
        
        parentView?.addSubview(closeButtonImageView!)
        parentView?.bringSubview(toFront: closeButtonImageView!)
        
    }
    
    func dismissScanning(){
        
        previewLayer?.connection.isEnabled = false
        self.captureSession?.removeOutput(metadataOutput)
        self.captureSession?.removeInput(captureInput)
        closeButtonImageView?.isUserInteractionEnabled = true
        closeButtonImageView?.addGestureRecognizer(gestureProvider())
        
    }
    
    func gestureProvider()->UITapGestureRecognizer{
        
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(tapRecogniser))
        tapGesture.numberOfTouchesRequired = 1
        tapGesture.numberOfTapsRequired = 1
        return tapGesture
        
    }
    
    
    
    func tapRecogniser(){
        print("taps recognised ")
        self.previewLayer?.removeFromSuperlayer()
        self.qrCodeFrameView?.removeFromSuperview()
        self.closeButtonImageView?.removeFromSuperview()
    }


}


/* iterate sub views recursively and remove it */

//        parentView?.subviews.forEach(){
//            print($0)
//              $0.removeFromSuperview()
//        }

/* shows the result of barcodes  in alertview  */
// should be moved under callback
/*func scannedResultAlert(scannedCode:String){
 let userIntimationAlert=UIAlertController(title: "yeppie ", message: "find your code \(scannedCode)", preferredStyle: .alert)
 userIntimationAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
 callingViewController!.present(userIntimationAlert, animated: true)
 }
 
 focusMarkLayer.frame = (self.previewLayer?.bounds)!
 focusLine.frame = (self.previewLayer?.bounds)!
 parentView?.layer.addSublayer(focusMarkLayer)
 
 parentView?.layer.addSublayer(focusLine)
 
 */

