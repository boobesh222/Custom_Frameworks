//
//  BarcodeFramework.h
//  BarcodeFramework
//
//  Created by IPhone Dev on 15/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BarcodeFramework.
FOUNDATION_EXPORT double BarcodeFrameworkVersionNumber;

//! Project version string for BarcodeFramework.
FOUNDATION_EXPORT const unsigned char BarcodeFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BarcodeFramework/PublicHeader.h>


