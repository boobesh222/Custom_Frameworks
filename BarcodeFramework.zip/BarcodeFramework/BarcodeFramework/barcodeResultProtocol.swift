//
//  File.swift
//  BarcodeScanner
//
//  Created by IPhone Dev on 11/05/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import Foundation


public protocol barcodeResultProtocol {
    func scannedBarcodeResult(_ barcode:String)
}
