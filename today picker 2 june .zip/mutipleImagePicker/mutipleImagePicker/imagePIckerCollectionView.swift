//
//  imagePIckerCollectionView.swift
//  multipleImagePIckerFramework
//
//  Created by Boobesh Balasubramanian  on 24/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import Photos

class ImagePickerCollectionView:UIViewController,UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,PHPhotoLibraryChangeObserver{
    
    /*outlets which handles dismissing the collection view */
    
    
    @IBOutlet weak var photosCollectionView: UICollectionView!
    
    var images:PHFetchResult<PHAsset>?
    let imageManager = PHCachingImageManager()
    var sourceType = PHFetchOptions()
    var collectionViewCellSize = CGSize()
    var imagesSelected = Set<PHAsset>()
    let collectionViewSelectedBackGroundImage = UIImageView()
    var collectionViewDeSelectionBackGroundImage = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("view did load ")
        fetchMediaAssets()
        //setUpCollectionViewLayoutProperties()
        var view = UIView()
        view.backgroundColor = UIColor.clear
        
        // collectionviewbackgroundimages
        photosCollectionView.allowsMultipleSelection = true

        collectionViewSelectedBackGroundImage.image = UIImage(named:"tick")
        collectionViewSelectedBackGroundImage.contentMode = .scaleAspectFit
        collectionViewDeSelectionBackGroundImage = view
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        print("didReceiveMemoryWarning")
    }
    
    
    /* collection view delegate  methods*/
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (images?.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var insertionResult = imagesSelected.insert((images?[indexPath.item])!)
        print("#######################################")
        print("item selected at \(indexPath.row)")
        print("selected temporary images array COUNT\(imagesSelected.count)")
        print("#######################################")


    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        
        var removedElement = imagesSelected.remove(at: (imagesSelected.index(of: (images?[indexPath.item])!))!)
        print("*****************************************")
        print("items deselected at \(indexPath.row)")
        print("selected temporary images array COUNT\(imagesSelected.count)")
        print("*****************************************")
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        
        collectionView.cellForItem(at: indexPath)?.backgroundView = collectionViewSelectedBackGroundImage
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        collectionView.cellForItem(at: indexPath)?.backgroundView = collectionViewDeSelectionBackGroundImage
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "albumImage", for: indexPath) as! CustomCollectionViewCell
        cell.imageAssests = images?[indexPath.item]
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.borderWidth = 0.5;
        if (cell.isSelected){
                cell.backgroundView = collectionViewSelectedBackGroundImage
        }else{
           cell.backgroundView = collectionViewDeSelectionBackGroundImage
        }
        return cell
    }
    
    /* collection view flow layout delegates  */
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width  = self.view.frame.width
        let height = self.view.frame.height
        return CGSize(width: width/4, height: height/6)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    /* photo library delegate methods which handle the changes  */
    
    func photoLibraryDidChange(_ changeInstance: PHChange){
        // yet to be implemented
    }
    
    /* methods which fetch the image Assests in the form of Phassests objects */
    
    func fetchMediaAssets() {
        sourceType.includeAssetSourceTypes = .typeUserLibrary
        images = PHAsset.fetchAssets(with: .image, options: nil)
        print("images assests count \(String(describing: images?.count))")
        PHPhotoLibrary.shared().register(self)
    }
    
    /* this method sets up the collection view layout properties */
    
    func setUpCollectionViewLayoutProperties(){
        collectionViewCellSize.width = 75
        collectionViewCellSize.height = 75
        let customizedFlowlayout = UICollectionViewFlowLayout()
               customizedFlowlayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0)
        customizedFlowlayout.minimumInteritemSpacing = 1
        customizedFlowlayout.minimumLineSpacing = 10
        customizedFlowlayout.itemSize = collectionViewCellSize
        photosCollectionView.collectionViewLayout = customizedFlowlayout
        
    }
    
   
}

// tips 


//collection view -> indexpathsofselecteditems






